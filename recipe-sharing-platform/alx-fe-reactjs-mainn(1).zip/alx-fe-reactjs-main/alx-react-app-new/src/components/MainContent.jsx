function MainContent(){
    return(
        <main style={{backgroundColor:'burlywood',color: 'white',textAlign:'center'}}>
          <p>I love to visit New York, Paris, and Tokyo.</p>
        </main>
    );
}

export default MainContent;