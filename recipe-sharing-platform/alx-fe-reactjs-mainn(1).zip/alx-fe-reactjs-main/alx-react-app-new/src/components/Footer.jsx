function Footer (){
    return(
        <footer style={{backgroundColor:'grey', color:'white', textAlign:'center'}}>
          <p>© 2023 City Lovers</p>
        </footer>
    );
}

export default Footer;