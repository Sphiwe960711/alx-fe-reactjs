// src/components/PostsComponent.jsx

import React from 'react';

const PostsComponent = () => {
  return (
    <div>
      <h1>Posts</h1>
      <p>This is the PostsComponent.</p>
    </div>
  );
};

export default PostsComponent;
