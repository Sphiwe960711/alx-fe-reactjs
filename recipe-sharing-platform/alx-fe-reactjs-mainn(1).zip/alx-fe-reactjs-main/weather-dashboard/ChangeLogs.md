git pull
git install (nodes)
git add .
git commit -m('')
git push