const ProfileDetails = () => <h2>Profile Details</h2>;
export default ProfileDetails;