const ProfileSettings = () => <h2>Profile Settings</h2>;
export default ProfileSettings;