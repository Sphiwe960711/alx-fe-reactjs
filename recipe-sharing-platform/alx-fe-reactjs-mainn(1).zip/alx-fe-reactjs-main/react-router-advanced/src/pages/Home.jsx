
const Home = () => <h1>Welcome to the Home Page</h1>;
export default Home;
