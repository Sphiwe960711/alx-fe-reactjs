import RegistrationForm from "./components/RegistrationForm"
import FormikForm from "./components/formikForm"
function App() {
  return (
    <div>
      <RegistrationForm />
      <h1>Registration Form</h1>
      <FormikForm />
    </div>
  )
}

export default App
